import spidev
import serial
import RPi.GPIO as GPIO
import time
import threading

# Pin definitions
SS_READ = 17
SS_WRITE = 27

# GPIO setup
GPIO.setmode(GPIO.BCM)
GPIO.setup(SS_READ, GPIO.OUT)
GPIO.setup(SS_WRITE, GPIO.OUT)

# Start with both deselected
GPIO.write(SS_READ, GPIO.LOW)
GPIO.write(SS_WRITE, GPIO.LOW)

# SPI setup
# Rememeber arduino SS pins are active low, so they need to be pulled LOW rather than HIGH to enable them. 
spi = spidev.SpiDev()
spi.open(0, 0)  # Bus 0, Device 0 (CE0)
spi.max_speed_hz = 500000

# UART setup
ser = serial.Serial('/dev/serial0', baudrate=9600, timeout=1)

# Function to read from SPI read device and send via UART
def main_loop():
    while True:
        GPIO.write(SS_WRITE, GPIO.HIGH) #deselect write slave device
        time.sleep(0.1)
        GPIO.write(SS_READ, GPIO.LOW) #select read slave device

        time.sleep(0.01)
        # Read 1 byte from SPI
        response = spi.xfer2([0x00])  # Dummy byte to read
        byte = response[0]
        print("SPI IN:", byte)

        # Send byte over UART
        ser.write(bytes([byte]))

        time.sleep(1)  # Adjust as needed

# Simulated ISR triggered when UART receives data
def uart_isr():
    while True:
        if ser.in_waiting > 0:
            data = ser.read()
            print("UART Received:", data)

            GPIO.write(SS_READ, GPIO.HIGH) #deselect read slave device
            time.sleep(0.1)
            GPIO.write(SS_WRITE, GPIO.LOW) #select write slave device

            time.sleep(0.01)
            # Send data over SPI to write device
            spi.xfer2([ord(data)])

            # Deselect after sending
            GPIO.write(SS_WRITE, GPIO.HIGH) #deselect write slave device

# Launch ISR in background
threading.Thread(target=uart_isr, daemon=True).start()

# Run main loop
main_loop()
