import serial
import spidev
import RPi.GPIO as GPIO
import time
import threading

# SPI setup
spi = spidev.SpiDev()
spi.open(0, 0)  # SPI bus 0, device 0 (CE0)
spi.max_speed_hz = 500000

# UART setup (HC-05 via /dev/serial0)
uart = serial.Serial("/dev/serial0", baudrate=9600, timeout=1)

# Simulated SPI ISR function
def spi_receive_isr():
    while True:
        # SPI read attempt - send dummy byte to receive from slave
        response = spi.xfer2([0x00])
        data = response[0]
        
        if data != 0x00:  # Only send if it's meaningful
            print(f"[ISR] SPI Received: {data}")
            uart.write(bytes([data]))

        time.sleep(0.1)  # Avoid CPU overload

# Start simulated SPI ISR thread
threading.Thread(target=spi_receive_isr, daemon=True).start()

# === Main Loop ===
try:
    while True:
        if uart.in_waiting > 0:
            byte_in = uart.read().decode('utf-8', errors='replace')
            print(f"[UART] Received via Bluetooth: {byte_in}")
        time.sleep(0.1)

except KeyboardInterrupt:
    print("Exiting...")
    spi.close()
    uart.close()
